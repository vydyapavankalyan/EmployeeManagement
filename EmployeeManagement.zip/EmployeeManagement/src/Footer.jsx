import React from 'react'

const Footer = () => {
  return (
    <div>
    <h2>&copy;  EMPLOYEE MANAGEMENT SYSTEM</h2> 

    </div>
  )
}

export default Footer